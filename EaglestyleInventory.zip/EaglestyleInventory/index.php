<?php require_once('includes/connection.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<html>
<title>Eagle Style School Wear Inventory System</title>
	<head>	
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<link media="all" rel="stylesheet" type="text/css" href="mainstyle.css"/>
		<link rel="stylesheet" type="text/css" href="tcal.css" />
		
		<script language="JavaScript" type="text/javascript" src="javascript/altRows.js"></script>
		<script language="JavaScript" type="text/javascript" src="javascript/tcal.js"></script>
		<script language="JavaScript" type="text/javascript" src="javascript/formValidate.js"></script>
	</head>
<body>
<div id="wrapper">
	<table id="header">
		<tr>
			<td>
				<div id="logo"><img src="image/bsu_logo.png"/></div>
				<div id="title1">Eagle Style School Wear</div>
				<div id="title2">Inventory System</div>
				<div class="date"><script type="text/javascript"> document.write(''+Date()+'') </script></div>
			</td>
		</tr>
	</table>
	<table id="marquee">
		<tr>
			<td>
				<marquee style="align="middle"  scrollamount="2" scrolldelay="10"  behavior="alternate">
					Eagle Style School Wear Inventory System 2016-2017...Eagle Style School Wear Inventory System 2016-2017...Eagle Style School Wear Inventory System 2016-2017...Eagle Style School Wear Inventory System 2016-2017...
				        Eagle Style School Wear Inventory System 2016-2017...Eagle Style School Wear Inventory System 2016-2017...Eagle Style School Wear Inventory System 2016-2017...Eagle Style School Wear Inventory System 2016-2017...
                                        Eagle Style School Wear Inventory System 2016-2017...Eagle Style School Wear Inventory System 2016-2017...Eagle Style School Wear Inventory System 2016-2017...Eagle Style School Wear Inventory System 2016-2017...
				</marquee>
			</td>
		</tr>
	</table>
	<table id="sidebar">
		<tr id="navbox">
			<td>
				<ul id="nav">
					<li><a href="index.php"class="current">Home</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="loginform.php">Login</a></li>
				</ul>
			</td>
		</tr>
	</table>
	<table id="contentbox">
		<tr>
			<td id="content">
			<div class="loginname">Welcome to Eagle Style School Wear Inventory System</div>					
			<div id="image"><img src="image/supply.jpg"/></div>					
			</td>
		</tr>
	</table>	
	<table id="footer">
		<tr>
			<td> All rights reserved 2016 - 2017.Eagle Style School Wear Inventory System.Developed by: Gikandi Ndoria</td>
		</tr>
	</table>
</div>
</body>
</html>
