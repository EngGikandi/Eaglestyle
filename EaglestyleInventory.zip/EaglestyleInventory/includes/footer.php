
	<table id="footer">
			<tr>
				<td> All rights reserved 2016-2017.Eagle style Inventory System.Developed by: Gikandi Ndoria</td>
			</tr>
	</table>
</div>
</body>
</html>
<?php
	// 5. Close connection
	mysql_close($conn);
?>