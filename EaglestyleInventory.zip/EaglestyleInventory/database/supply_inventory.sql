-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 15, 2013 at 08:33 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `supply_inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `availability`
--

DROP TABLE IF EXISTS `availability`;
CREATE TABLE IF NOT EXISTS `availability` (
  `avail_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` varchar(100) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `rec_quantity` int(255) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `price` int(255) NOT NULL,
  `item_type` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `amount` int(255) NOT NULL,
  PRIMARY KEY (`avail_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `availability`
--

INSERT INTO `availability` (`avail_id`, `item_id`, `item_name`, `brand`, `rec_quantity`, `unit`, `price`, `item_type`, `category`, `amount`) VALUES
(1, '', 'ballpen', 'genius', 8, 'box', 100, 'returnable', 'scientific equipment', 0),
(2, '', 'bondpaper', 'e4tech', 5, 'rem', 150, 'returnable', 'scientific equipment', 0),
(18, '', '', '', 3, '', 0, '', '', 0),
(19, '', '', '', 2, '', 0, '', '', 0),
(20, '', '', '', 5, '', 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

DROP TABLE IF EXISTS `borrow`;
CREATE TABLE IF NOT EXISTS `borrow` (
  `bar_id` int(11) NOT NULL AUTO_INCREMENT,
  `bar_item` varchar(50) NOT NULL,
  `person_bar` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date_bar` date NOT NULL,
  PRIMARY KEY (`bar_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`bar_id`, `bar_item`, `person_bar`, `quantity`, `date_bar`) VALUES
(5, 'monitor', '', 1, '2013-03-12'),
(6, 'monitor', '', 1, '2013-03-12');

-- --------------------------------------------------------

--
-- Table structure for table `borrowed_item`
--

DROP TABLE IF EXISTS `borrowed_item`;
CREATE TABLE IF NOT EXISTS `borrowed_item` (
  `id` int(11) NOT NULL,
  `employee_name` varchar(50) NOT NULL,
  `item_code` int(11) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `quantity` int(255) NOT NULL,
  `date_borrow` datetime NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Dumping data for table `borrowed_item`
--

INSERT INTO `borrowed_item` (`id`, `employee_name`, `item_code`, `item_name`, `quantity`, `date_borrow`, `status`) VALUES
(15, 'Rolly B. Abellanosa', 12345, 'monitor', 1, '2013-03-15 00:05:11', ''),
(15, 'Rolly B. Abellanosa', 23456, 'speaker', 1, '2013-03-15 00:05:11', ''),
(16, 'Rolly B. Abellanosa', 12345, 'monitor', 1, '2013-03-15 00:11:03', 'Borrowed'),
(16, 'Rolly B. Abellanosa', 23456, 'speaker', 1, '2013-03-15 00:11:03', 'Borrowed'),
(16, 'Rolly B. Abellanosa', 11111, 'mouse', 1, '2013-03-15 00:11:03', 'Borrowed'),
(16, 'Rolly B. Abellanosa', 22222, 'keyboard', 1, '2013-03-15 00:11:03', 'Borrowed');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

DROP TABLE IF EXISTS `brand`;
CREATE TABLE IF NOT EXISTS `brand` (
  `brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(50) NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `brand`
--


-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(50) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
(1, 'office supplies'),
(3, 'construction materials'),
(4, 'technical and scientific  equipment'),
(5, 'sports equipment'),
(6, 'industrial machineries');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `dept_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_id`, `description`) VALUES
(1, 'accounting'),
(2, 'finance'),
(3, 'principal''s office'),
(4, 'registrar');

-- --------------------------------------------------------

--
-- Table structure for table `itemlist`
--

DROP TABLE IF EXISTS `itemlist`;
CREATE TABLE IF NOT EXISTS `itemlist` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` int(50) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `brand_name` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_name` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `type_name` varchar(50) NOT NULL,
  `cat_name` varchar(50) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(50) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=214 ;

--
-- Dumping data for table `itemlist`
--

INSERT INTO `itemlist` (`item_id`, `item_code`, `item_name`, `brand_name`, `quantity`, `unit_name`, `price`, `type_name`, `cat_name`, `supplier_id`, `supplier_name`) VALUES
(206, 12345, 'monitor', 'genius', 2, 'pcs', 150, 'returnable', 'office supplies', 0, 'data world'),
(207, 23456, 'speaker', 'genius', 5, 'pcs', 200, 'returnable', 'technical and scientific  equipment', 0, 'data world'),
(208, 11111, 'mouse', 'genius', 2, 'pcs', 200, 'returnable', 'office supplies', 0, 'data world'),
(209, 22222, 'keyboard', 'genius', 3, 'pcs', 300, 'returnable', 'office supplies', 0, 'data world');

-- --------------------------------------------------------

--
-- Table structure for table `item_type`
--

DROP TABLE IF EXISTS `item_type`;
CREATE TABLE IF NOT EXISTS `item_type` (
  `itype_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(100) NOT NULL,
  PRIMARY KEY (`itype_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `item_type`
--

INSERT INTO `item_type` (`itype_id`, `type_name`) VALUES
(1, 'returnable'),
(2, 'consumable'),
(3, 'disposable');

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

DROP TABLE IF EXISTS `position`;
CREATE TABLE IF NOT EXISTS `position` (
  `pos_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`pos_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`pos_id`, `description`) VALUES
(1, 'principal'),
(2, 'teacher'),
(3, 'librarian'),
(4, 'guard'),
(5, 'accountant');

-- --------------------------------------------------------

--
-- Table structure for table `price`
--

DROP TABLE IF EXISTS `price`;
CREATE TABLE IF NOT EXISTS `price` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` int(255) NOT NULL,
  PRIMARY KEY (`price_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `price`
--


-- --------------------------------------------------------

--
-- Table structure for table `purchase_item`
--

DROP TABLE IF EXISTS `purchase_item`;
CREATE TABLE IF NOT EXISTS `purchase_item` (
  `po_id` int(11) NOT NULL,
  `item_code` int(20) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `supplier_name` varchar(50) NOT NULL,
  `ord_qty` int(255) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `price` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `ord_date` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_item`
--

INSERT INTO `purchase_item` (`po_id`, `item_code`, `item_name`, `supplier_name`, `ord_qty`, `unit`, `price`, `total`, `ord_date`, `status`) VALUES
(1, 12345, 'folder', 'godem comercial', 1, 'pcs', 2, 0, '2013-03-12', ''),
(1, 23456, 'envenlop', 'godem comercial', 2, 'pcs', 3, 0, '2013-03-12', ''),
(1, 34567, 'ballpen', 'godem comercial', 3, 'boxes', 150, 0, '2013-03-12', ''),
(2, 12345, 'monitor', 'data world', 2, 'pcs', 150, 0, '2013-03-14', ''),
(2, 23456, 'speaker', 'data world', 3, 'pcs', 200, 0, '2013-03-14', '');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order`
--

DROP TABLE IF EXISTS `purchase_order`;
CREATE TABLE IF NOT EXISTS `purchase_order` (
  `po_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `date_ordered` date NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`po_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `purchase_order`
--


-- --------------------------------------------------------

--
-- Table structure for table `quantity`
--

DROP TABLE IF EXISTS `quantity`;
CREATE TABLE IF NOT EXISTS `quantity` (
  `qnty_id` int(11) NOT NULL AUTO_INCREMENT,
  `quantity` int(255) NOT NULL,
  PRIMARY KEY (`qnty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `quantity`
--


-- --------------------------------------------------------

--
-- Table structure for table `rec_item`
--

DROP TABLE IF EXISTS `rec_item`;
CREATE TABLE IF NOT EXISTS `rec_item` (
  `rec_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(50) NOT NULL,
  `supplier_name` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `qty_left` int(11) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `item_type` varchar(10) NOT NULL,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`rec_item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `rec_item`
--

INSERT INTO `rec_item` (`rec_item_id`, `item_name`, `supplier_name`, `brand`, `qty_left`, `unit`, `price`, `item_type`, `category`) VALUES
(16, 'speaker', 'data world', 'genius', 5, 'pcs', 200, 'returnable', 'scientific equipment');

-- --------------------------------------------------------

--
-- Table structure for table `released_item`
--

DROP TABLE IF EXISTS `released_item`;
CREATE TABLE IF NOT EXISTS `released_item` (
  `rel_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `released_qty` int(11) NOT NULL,
  `item_type` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `date_released` date NOT NULL,
  PRIMARY KEY (`rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `released_item`
--


-- --------------------------------------------------------

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
CREATE TABLE IF NOT EXISTS `report` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` int(11) NOT NULL,
  `date_reported` date NOT NULL,
  `time_reported` time NOT NULL,
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `report`
--


-- --------------------------------------------------------

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
CREATE TABLE IF NOT EXISTS `request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `req_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `quantity` int(255) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `price` int(255) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `req_id`, `name`, `subject`, `item_name`, `quantity`, `unit`, `price`, `date`) VALUES
(22, 1, 'ariel abriol', 'for laboratory 1', 'monitor', 2, 'pcs', 0, '2013-03-15 00:57:31'),
(23, 1, 'ariel abriol', 'for laboratory 1', 'speaker', 2, 'pcs', 0, '2013-03-15 00:57:31');

-- --------------------------------------------------------

--
-- Table structure for table `return`
--

DROP TABLE IF EXISTS `return`;
CREATE TABLE IF NOT EXISTS `return` (
  `return_id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`return_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `return`
--


-- --------------------------------------------------------

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE IF NOT EXISTS `status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`status_id`, `status_name`) VALUES
(1, 'Approved'),
(2, 'Canceled');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
CREATE TABLE IF NOT EXISTS `supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `supplier_name`, `address`, `contact_person`, `contact`, `email`) VALUES
(26, 'data world', 'cdo', 'ariel abriol', '0123456789', 'ariel@yahoo.com'),
(30, 'godem comercial', 'alubijid, misamis oriental', 'ariel abriol', '09358944967', 'ariel@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

DROP TABLE IF EXISTS `unit`;
CREATE TABLE IF NOT EXISTS `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(20) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`unit_id`, `unit_name`) VALUES
(1, 'pc'),
(2, 'pcs'),
(3, 'box'),
(4, 'boxes'),
(5, 'gallon'),
(7, 'meter'),
(9, 'yard'),
(11, 'rem'),
(12, 'bandle');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `utype_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `department` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `username` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `password` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `date` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `utype_id`, `name`, `department`, `position`, `username`, `password`, `address`, `contact`, `date`) VALUES
(50, 1, 'Rolly B. Abellanosa', 'Supply', 'OIC', 'rolly', 'axlrose', 'Laguindingan, Misamis Oriental', '09263778273', '2013-03-04'),
(51, 2, 'wilbur ramos', 'accounting', 'book keeper', 'wilbur', 'ramos', 'Laguindingan, Misamis Oriental', '09358944967', '2013-03-04'),
(52, 3, 'ariel abriol', 'finance', 'unkown', 'ariel', 'abriol', 'alubijid, misamis oriental', '09358944967', '2013-03-04');

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

DROP TABLE IF EXISTS `user_type`;
CREATE TABLE IF NOT EXISTS `user_type` (
  `utype_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` varchar(50) NOT NULL,
  PRIMARY KEY (`utype_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`utype_id`, `user_type`) VALUES
(1, 'Administrator'),
(2, 'Authorized'),
(3, 'Common ');
