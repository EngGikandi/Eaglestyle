<?php require_once('includes/header.php');?>
<?php require_once('includes/connection.php');?>
<?php
if(isset($_GET["attempt"]))
{
$attempt=$_GET["attempt"];
}
?>
<?php
session_start();
?>

	<table id="sidebar">
			<tr id="navbox">
				<td>
					<ul id="nav">
						<li><a href="index.php">Home</a></li>
						<li><a href="about.php"class="current">About</a></li>
						<li><a href="loginform.php">Login</a></li>
					</ul>
				</td>
			</tr>
	</table>
<table id="contentbox">
	<tr>
		<td id="content">
			<div class="loginname">About Eagle Style School Wear Inventory System</div>
			<br />
			<div id="about">
			Eagle Style School Wear Inventory system deals primarily with determining the size and placement 
			of the products within company. 
			It is also concerned with the importance of forecasting the required inventory, availability of physical space, 
			and cost in carrying those inventories to maintain the planned course of production against the random fluctuations, 
			or shortage of materials. One way of managing inventory is to have an automated system in place 
			that can instantly track and update the information about the products.
			</div><br /><br /><br /><br /><br /><br /><br /><br /><br />
		</td>
	</tr>
</table>	
<?php require('includes/footer.php');?>
