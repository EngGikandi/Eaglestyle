<?php require_once ("includes/connection.php"); ?>
<?php
if (isset($_GET['item_id']) && is_numeric($_GET['item_id']))
	{
		$item_id = $_GET['item_id'];
		$result = mysql_query("DELETE FROM itemlist WHERE item_id=$item_id") or die(mysql_error());
		header("Location: item.php");
	}

?>
